#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<graphics.h>
#include<windows.h>
#include<math.h>
#include<time.h>

#pragma comment(lib,"Winmm.lib")

#define High 600
#define Width 800//��Ϸ����ߴ�
#define sizewidth 80
#define sizehigh 100//�����ƺ�ߴ�
#define num_width 5
#define num_length 9//��ƺ����
#define py 85//��ƫ���� 
#define px 45//��ƫ����
#define num_zombie 18//��ʬ����
int map[num_width][num_length] = { 0 };//�洢��Ϸ�е�Ԫ�أ�0�յأ�1�㶹���֣�2���տ�

int seconds= time((time_t*)NULL);//����ǵ���������û��������տ������⣬icon������ʬ��ֲ��ļ��������ֿ�
//��ʱ��Ļ����Ӳ��ӹ���

int t = 10000000000;//���Ŷ����ļ�ʱ��

IMAGE img_bg;//��ƺͼ
IMAGE img_pea;//�㶹ͼ
IMAGE img_peabg;//�㶹����ͼ
IMAGE img_sun;//����ͼ
IMAGE img_sunflower;//���տ�ͼ
IMAGE img_peashooter;//�㶹����ͼ
IMAGE img_zombie;//��ʬͼ
IMAGE img_peashooter_board;//�㶹���ְ�ͼ
IMAGE img_sunflower_board;//���տ���ͼ
IMAGE img_car;//С��ͼ
IMAGE img_carbg;//С������ͼ
IMAGE img_sunbg;//̫������ͼ
IMAGE img_board;//��ͼ
IMAGE img_begin;//��ʼ����
IMAGE img_lose;//ʧ�ܽ���
IMAGE img_win;//�ɹ�����
IMAGE img_num;//ʣ�ཀྵʬ��
IMAGE chan;//chanzi

//��ʬ����ͼ
IMAGE z1;
IMAGE z2;
IMAGE z3;
IMAGE z4;
IMAGE z5;
IMAGE z6;
IMAGE z7;
IMAGE z8;
IMAGE z1_bg;
IMAGE z2_bg;
IMAGE z3_bg;
IMAGE z4_bg;
IMAGE z5_bg;
IMAGE z6_bg;
IMAGE z7_bg;
IMAGE z8_bg;

//���տ�����ͼ
IMAGE s1;
IMAGE s2;
IMAGE s3;
IMAGE s4;
IMAGE s5;
IMAGE s6;
IMAGE s7;
IMAGE s8;
IMAGE s9;
IMAGE s10;
IMAGE s11;
IMAGE s12;
IMAGE s13;
IMAGE s14;
IMAGE s15;
IMAGE s16;
IMAGE s17;
IMAGE s18;
IMAGE s1_bg;
IMAGE s2_bg;
IMAGE s3_bg;
IMAGE s4_bg;
IMAGE s5_bg;
IMAGE s6_bg;
IMAGE s7_bg;
IMAGE s8_bg;
IMAGE s9_bg;
IMAGE s10_bg;
IMAGE s11_bg;
IMAGE s12_bg;
IMAGE s13_bg;
IMAGE s14_bg;
IMAGE s15_bg;
IMAGE s16_bg;
IMAGE s17_bg;
IMAGE s18_bg;

//�㶹���ֶ���ͼ
IMAGE b1;
IMAGE b2;
IMAGE b3;
IMAGE b4;
IMAGE b5;
IMAGE b6;
IMAGE b7;
IMAGE b8;
IMAGE b9;
IMAGE b10;
IMAGE b11;
IMAGE b12;
IMAGE b1_bg;
IMAGE b2_bg;
IMAGE b3_bg;
IMAGE b4_bg;
IMAGE b5_bg;
IMAGE b6_bg;
IMAGE b7_bg;
IMAGE b8_bg;
IMAGE b9_bg;
IMAGE b10_bg;
IMAGE b11_bg;
IMAGE b12_bg;


int peashooter_x, peashooter_y;//�㶹����λ��
int sunflower_x, sunflower_y;//���տ�λ��
int zombie_x[num_zombie] = { 900,950,1000,1020,1050,1200,1230,1100,2300,3000,1100,1740,1200,3000,2500,2300,2500,2890 }, zombie_y[num_zombie];//��ʬλ��
int pea_x[num_zombie], pea_y[num_zombie];//�㶹λ��
int pea_v[num_zombie];//�㶹�ٶ�
int zombie_v[num_zombie];//��ʬ�ٶ�
int is_zombie[num_zombie];//�Ƿ��н�ʬ
int is_shooter;//�Ƿ����㶹����
int is_pea[num_zombie];//�Ƿ����ӵ�
int hit[num_zombie];//��ʬ�ܻ������
int car_x[num_width] = { -30,-30,-30,-30,-30 }, car_y[num_width] = { 100,200,300,400,500 };//С��λ��
int is_carmove[num_width];//С���Ƿ��ƶ�
int is_car[num_width];//�Ƿ���С��
int sun_x, sun_y,sun_v;//��������
int sunplant_x, sunplant_y;
int score;//������


int i, j;//��ͼѭ������
int z;//��ʬѭ������

int is_peashooter_moveplant;//�Ƿ��ƶ����֣����ڽ�ֲ����ק��������
int is_peashooter_planted;//�Ƿ�����ֲ

int is_sunflower_moveplant;//�Ƿ��ƶ����տ������ڽ�ֲ����ק��������
int is_sunflower_planted;//�Ƿ�����ֲ
int is_sunflower;//�Ƿ������տ�

int totalnum = num_zombie;

void startup() {//���ݳ�ʼ��
	
	initgraph(Width, High);

	HWND hWnd = GetHWnd();//��ô��ھ��
	SetWindowText(hWnd, ("Plants VS Zombies"));//��ô��ھ��

	seconds %= 100000000;

	loadimage(&img_bg, "bg.jpg");
	loadimage(&img_pea, "pea.jpg");
	loadimage(&img_sun, "sun.jpg");
	loadimage(&img_sunflower, "sunflower.jpg");
	loadimage(&img_peashooter, "peashooter.jpg");
	loadimage(&img_peashooter_board, "peashooter_board.jpg");
	loadimage(&img_sunflower_board, "sun_board.jpg");
	loadimage(&img_zombie, "zombie.jpg");
	loadimage(&img_car, "car.jpg");
	loadimage(&img_peabg, "pea_bg.jpg");
	loadimage(&img_sunbg, "sun_bg.jpg");
	loadimage(&img_carbg, "car_bg.jpg");
	loadimage(&img_board, "board.jpg");
	loadimage(&img_begin, "begin.jpg");
	loadimage(&img_win, "win.jpg");
	loadimage(&img_lose, "lose.jpg");
	loadimage(&img_num, "num.jpg");
	loadimage(&chan, "chan.jpg");

	loadimage(&z1, "z1.jpg");
	loadimage(&z2, "z2.jpg");
	loadimage(&z3, "z3.jpg");
	loadimage(&z4, "z4.jpg");
	loadimage(&z5, "z5.jpg");
	loadimage(&z6, "z6.jpg");
	loadimage(&z7, "z7.jpg");
	loadimage(&z8, "z8.jpg");
	loadimage(&z1_bg, "z1_bg.jpg");
	loadimage(&z2_bg, "z2_bg.jpg");
	loadimage(&z3_bg, "z3_bg.jpg");
	loadimage(&z4_bg, "z4_bg.jpg");
	loadimage(&z5_bg, "z5_bg.jpg");
	loadimage(&z6_bg, "z6_bg.jpg");
	loadimage(&z7_bg, "z7_bg.jpg");
	loadimage(&z8_bg, "z8_bg.jpg");



	loadimage(&s1, "s1.jpg");
	loadimage(&s2, "s2.jpg");
	loadimage(&s3, "s3.jpg");
	loadimage(&s4, "s4.jpg");
	loadimage(&s5, "s5.jpg");
	loadimage(&s6, "s6.jpg");
	loadimage(&s7, "s7.jpg");
	loadimage(&s8, "s8.jpg");
	loadimage(&s9, "s9.jpg");
	loadimage(&s10, "s10.jpg");
	loadimage(&s11, "s11.jpg");
	loadimage(&s12, "s12.jpg");
	loadimage(&s13, "s13.jpg");
	loadimage(&s14, "s14.jpg");
	loadimage(&s15, "s15.jpg");
	loadimage(&s16, "s16.jpg");
	loadimage(&s17, "s17.jpg");
	loadimage(&s18, "s18.jpg");
	loadimage(&s1_bg, "s1_bg.jpg");
	loadimage(&s2_bg, "s2_bg.jpg");
	loadimage(&s3_bg, "s3_bg.jpg");
	loadimage(&s4_bg, "s4_bg.jpg");
	loadimage(&s5_bg, "s5_bg.jpg");
	loadimage(&s6_bg, "s6_bg.jpg");
	loadimage(&s7_bg, "s7_bg.jpg");
	loadimage(&s8_bg, "s8_bg.jpg");
	loadimage(&s9_bg, "s9_bg.jpg");
	loadimage(&s10_bg, "s10_bg.jpg");
	loadimage(&s11_bg, "s11_bg.jpg");
	loadimage(&s12_bg, "s12_bg.jpg");
	loadimage(&s13_bg, "s13_bg.jpg");
	loadimage(&s14_bg, "s14_bg.jpg");
	loadimage(&s15_bg, "s15_bg.jpg");
	loadimage(&s16_bg, "s16_bg.jpg");
	loadimage(&s17_bg, "s17_bg.jpg");
	loadimage(&s18_bg, "s18_bg.jpg");

	loadimage(&b1, "b1.jpg");
	loadimage(&b2, "b2.jpg");
	loadimage(&b3, "b3.jpg");
	loadimage(&b4, "b4.jpg");
	loadimage(&b5, "b5.jpg");
	loadimage(&b6, "b6.jpg");
	loadimage(&b7, "b7.jpg");
	loadimage(&b8, "b8.jpg");
	loadimage(&b9, "b9.jpg");
	loadimage(&b10, "b10.jpg");
	loadimage(&b11, "b11.jpg");
	loadimage(&b12, "b12.jpg");
	loadimage(&b1_bg, "b1_bg.jpg");
	loadimage(&b2_bg, "b2_bg.jpg");
	loadimage(&b3_bg, "b3_bg.jpg");
	loadimage(&b4_bg, "b4_bg.jpg");
	loadimage(&b5_bg, "b5_bg.jpg");
	loadimage(&b6_bg, "b6_bg.jpg");
	loadimage(&b7_bg, "b7_bg.jpg");
	loadimage(&b8_bg, "b8_bg.jpg");
	loadimage(&b9_bg, "b9_bg.jpg");
	loadimage(&b10_bg, "b10_bg.jpg");
	loadimage(&b11_bg, "b11_bg.jpg");
	loadimage(&b12_bg, "b12_bg.jpg");

	peashooter_x = 0;
	peashooter_y = 0;
	sunflower_x = 0;
	sunflower_y = 0;
	
	score = 100;//��ʼ������
	sun_x = rand() % (Width - 100);
	sun_y = -100;
	sun_v = 8;

	sunplant_x = -50;
	sunplant_y = -50;
	//pea_x = peashooter_x;
	//pea_y = peashooter_y;

	//zombie_x = 800;
	//zombie_y = 100;

	//pea_v = 50;
	//zombie_v = -1;

	//hit = 0;

	//is_zombie = 1;//��ʼ���ֽ�ʬ
	//is_pea = 0;//��ʼ���ӵ�
	is_shooter = 0;//��ʼ���㶹����
	is_sunflower = 0;//��ʼ�����տ�



	is_peashooter_moveplant = 0;//��ʼֲ�ﲻ������ƶ�
	is_peashooter_planted = 0;//��ʼ����ֲ

	is_sunflower_moveplant = 0;//��ʼֲ�ﲻ������ƶ�
	is_sunflower_planted = 0;//��ʼ����ֲ

	for (z = 0;z < num_zombie;z++) {
		zombie_v[z] = -5;
		is_zombie[z] = 1;
		hit[z] = 0;
		zombie_y[z] = 100 * (rand() % 5)+50;
	}//��ʬ��ʼ���趨
	for (z = 0;z < num_zombie;z++) {
		pea_x[z] = 0;
		pea_y[z] = 0;
		pea_v[z] = 50;
		is_pea[z] = 0;
	}
	for (i = 0;i < num_width;i++) {
		is_car[i] = 1;
		is_carmove[i] = 0;
	}
	


	putimage(0, 0, &img_begin);

	mciSendString("open begin.mp3", NULL, 0, 0);
	mciSendString("play begin.mp3 repeat", NULL, 0, 0);

	while (1)
	{

		MOUSEMSG m; m = GetMouseMsg();
		if (m.uMsg == WM_LBUTTONDOWN&&m.x>100&&m.x<680&&m.y>500&&m.y<540)
		{
			mciSendString("close begin.mp3", NULL, 0, 0);
			break;
		}

	}
	BeginBatchDraw();
}

void show() {//��ʾ����
	
	mciSendString("open playing.mp3", NULL, 0, 0);
	mciSendString("play playing.mp3 repeat", NULL, 0, 0);
	putimage(0, 0, &img_bg);//��ʾ��ƺ����ͼ
	
	for (i = 0;i < num_width;i++) {
		for (j = 0;j < num_length;j++) {
			if (map[i][j] == 1) {
				if (t % 12 == 0) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b1_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b1, SRCINVERT);
				}
				if (t % 12 == 1) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b2_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b2, SRCINVERT);
				}
				if (t % 12 == 2) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b3_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b3, SRCINVERT);
				}
				if (t % 12 == 3) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b4_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b4, SRCINVERT);
				}
				if (t % 12 == 4) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b5_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b5, SRCINVERT);
				}
				if (t % 12 == 5) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b6_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b6, SRCINVERT);
				}
				if (t % 12 == 6) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b7_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b7, SRCINVERT);
				}
				if (t % 12 == 7) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b8_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b8, SRCINVERT);
				}
				if (t % 12 == 8) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b9_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b9, SRCINVERT);
				}
				if (t % 12 == 9) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b10_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b10, SRCINVERT);
				}
				if (t % 12 == 10) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b11_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b11, SRCINVERT);
				}
				if (t % 12 == 11) {
					putimage(px + sizewidth * j, py + sizehigh * i, &b12_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &b12, SRCINVERT);
				}
			}
			if (map[i][j] == 2) {
				if (t % 18 == 0) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s1_bg,NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s1, SRCINVERT);
				}
				if (t % 18 == 1) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s2_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s2, SRCINVERT);
				}
				if (t % 18 == 2) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s3_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s3, SRCINVERT);
				}
				if (t % 18 == 3) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s4_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s4, SRCINVERT);
				}
				if (t % 18 == 4) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s5_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s5, SRCINVERT);
				}
				if (t % 18 == 5) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s6_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s6, SRCINVERT);
				}
				if (t % 18 == 6) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s7_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s7, SRCINVERT);
				}
				if (t % 18 == 7) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s8_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s8, SRCINVERT);
				}
				if (t % 18 == 8) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s9_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s9, SRCINVERT);
				}
				if (t % 18 == 9) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s10_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s10, SRCINVERT);
				}
				if (t % 18 == 10) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s11_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s11, SRCINVERT);
				}
				if (t % 18 == 11) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s12_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s12, SRCINVERT);
				}
				if (t % 18 == 12) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s13_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s13, SRCINVERT);
				}
				if (t % 18 == 13) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s14_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s14, SRCINVERT);
				}
				if (t % 18 == 14) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s15_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s15, SRCINVERT);
				}
				if (t % 18 == 15) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s16_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s16, SRCINVERT);
				}
				if (t % 18 == 16) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s17_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s17, SRCINVERT);
				}
				if (t % 18 == 17) {
					putimage(px + sizewidth * j, py + sizehigh * i, &s18_bg, NOTSRCERASE);
					putimage(px + sizewidth * j, py + sizehigh * i, &s18, SRCINVERT);
				}
			}
		}
	}


	if (is_shooter == 1) {
		putimage(peashooter_x, peashooter_y, &b1_bg, NOTSRCERASE);
		putimage(peashooter_x, peashooter_y, &b1, SRCINVERT);
	}
	if (is_sunflower == 1) {
		putimage(sunflower_x, sunflower_y, &s1_bg, NOTSRCERASE);
		putimage(sunflower_x, sunflower_y, &s1, SRCINVERT);
	}

	time_t timer;
	timer = time(NULL);


	for (z = 0;z < num_zombie;z++) {
		if (is_zombie[z] == 1) {
			if (zombie_x[z] / 10 % 8 == 0) {
				putimage(zombie_x[z], zombie_y[z]-35, &z1_bg,NOTSRCERASE);
				putimage(zombie_x[z], zombie_y[z]-35, &z1, SRCINVERT);
			}
			if (zombie_x[z] / 10 % 8 == 1) {
				putimage(zombie_x[z], zombie_y[z] - 35, &z2_bg, NOTSRCERASE);
				putimage(zombie_x[z], zombie_y[z] - 35, &z2, SRCINVERT);
			}
			if (zombie_x[z] / 10 % 8 == 2) {
				putimage(zombie_x[z], zombie_y[z] - 35, &z3_bg, NOTSRCERASE);
				putimage(zombie_x[z], zombie_y[z] - 35, &z3, SRCINVERT);
			}
			if (zombie_x[z] / 10 % 8 == 3) {
				putimage(zombie_x[z], zombie_y[z] - 35, &z4_bg, NOTSRCERASE);
				putimage(zombie_x[z], zombie_y[z] - 35, &z4, SRCINVERT);
			}
			if (zombie_x[z] / 10 % 8 == 4) {
				putimage(zombie_x[z], zombie_y[z] - 35, &z5_bg, NOTSRCERASE);
				putimage(zombie_x[z], zombie_y[z] - 35, &z5, SRCINVERT);
			}
			if (zombie_x[z] / 10 % 8 == 5) {
				putimage(zombie_x[z], zombie_y[z] - 35, &z6_bg, NOTSRCERASE);
				putimage(zombie_x[z], zombie_y[z] - 35, &z6, SRCINVERT);
			}
			if (zombie_x[z] / 10 % 8 == 6) {
				putimage(zombie_x[z], zombie_y[z] - 35, &z7_bg, NOTSRCERASE);
				putimage(zombie_x[z], zombie_y[z] - 35, &z7, SRCINVERT);
			}
			if (zombie_x[z] / 10 % 8 == 7) {
				putimage(zombie_x[z], zombie_y[z] - 35, &z8_bg, NOTSRCERASE);
				putimage(zombie_x[z], zombie_y[z] - 35, &z8, SRCINVERT);
			}
		}
	}
	for (z = 0;z < num_zombie;z++) {
		if (is_pea[z] == 1) {
			putimage(pea_x[z], pea_y[z], &img_peabg,NOTSRCERASE);
			putimage(pea_x[z], pea_y[z], &img_pea, SRCINVERT);
		}
	}
	for (i = 0;i < num_width;i++) {
		if (is_car[i] == 1) {
			putimage(car_x[i], car_y[i], &img_carbg, NOTSRCERASE);
			putimage(car_x[i], car_y[i], &img_car, SRCINVERT);
		}
	}
	putimage(0, 0, &img_board);
	putimage(155, 10, &img_sunflower_board);//��ʾ���տ���Ƭͼ
	putimage(95, 10, &img_peashooter_board);//��ʾ�㶹���ֿ�Ƭͼ
	putimage(215, 0, &chan);

	putimage(sun_x, sun_y, &img_sunbg, NOTSRCERASE);
	putimage(sun_x, sun_y, &img_sun, SRCINVERT);
	
	

	TCHAR s[5];
	_stprintf_s(s, _T("%d"), score);
	outtextxy(27, 65, s);

	putimage(550, 10, &img_num);

	TCHAR t[5];
	_stprintf_s(t, _T("%d"), totalnum);
	outtextxy(630, 23, t);settextcolor(BLACK);

	setbkmode(TRANSPARENT);
	FlushBatchDraw();
}
void updateWithoutInput() {//���û������޹صĸ���
	for (z = 0;z < num_zombie;z++) {
		zombie_x[z] += zombie_v[z];
	}

	for (i = 0;i < num_width;i++) {
		for (j = 0;j < num_length;j++) {
			for (z = 0;z < num_zombie;z++) {
				if (zombie_v[z] != -1) {
					if ((py + sizehigh * i > zombie_y[z] - 20) && (py + sizehigh * i < zombie_y[z] + 50) && map[i][j] == 1 && zombie_x[z] < 800) {
						pea_y[z] = py + sizehigh * i;
						is_pea[z] = 1;
						pea_x[z] += pea_v[z];//����ӵ�
					}
					if (pea_x[z] >= zombie_x[z]) {
						pea_x[z] = px + sizewidth * j;
						pea_y[z] = py + sizehigh * i;
						mciSendString("close hitmusic", NULL, 0, NULL);
						mciSendString("open hit.mp3 alias hitmusic", NULL, 0, NULL);
						mciSendString("play hitmusic", NULL, 0, NULL);
						hit[z]++;//���н�ʬ���ӵ���ʧ 
					}
					if (hit[z] == 10) {
						is_zombie[z] = 0;
						zombie_x[z] = 800;
						zombie_y[z] = 800;
						zombie_v[z] = 0;
						is_pea[z] = 0;
						pea_v[z] = 0;
						pea_x[z] = 0;
						pea_y[z] = 0;//��ʬ��ʧ���ӵ����ٻ���
					}
					if (is_zombie[z] == 0) {
						totalnum = num_zombie - 1 - z;
					}
				}
				if ((py + sizehigh * i > zombie_y[z] - 20) && (py + sizehigh * i < zombie_y[z] + 50) && (zombie_x[z] - car_x[i]) < 100 && zombie_x[z] < 800) {
					is_zombie[z] = 0;
					zombie_x[z] = 800;
					zombie_y[z] = 800;
					zombie_v[z] = 0;
					is_carmove[i] = 1;
					mciSendString("stop carmusic", NULL, 0, NULL);
					mciSendString("close carmusic", NULL, 0, NULL);
					mciSendString("open car.mp3 alias carmusic", NULL, 0, NULL);
					mciSendString("play carmusic", NULL, 0, NULL);
				}//����ʬ����С��
				if ((py + sizehigh * i > zombie_y[z] - 20) && (py + sizehigh * i < zombie_y[z] + 50) &&(map[i][j]!=0)&&(zombie_x[z] - (px + sizewidth * j)) < 10) {
					zombie_v[z] = -10;
					map[i][j] = 0;
					mciSendString("close etmusic", NULL, 0, NULL);
					mciSendString("open eaten.mp3 alias etmusic", NULL, 0, NULL);
					mciSendString("play etmusic", NULL, 0, NULL);
				}
				else if ((py + sizehigh * i > zombie_y[z] - 20) && (py + sizehigh * i < zombie_y[z] + 50) && (map[i][j] != 0) && (zombie_x[z] - (px + sizewidth * j)) < 40 && (zombie_x[z] - (px + sizewidth * j)) > 25) {
					zombie_v[z] = -1;
					mciSendString("close egmusic", NULL, 0, NULL);
					mciSendString("open eating.mp3 alias egmusic", NULL, 0, NULL);
					mciSendString("play egmusic", NULL, 0, NULL);
				}//��ʬ��ֲ��
				if (is_carmove[i] == 1) {
					car_x[i] += 1;
					
				}//С���ƶ�
				if (car_x[i] > 900) {
					car_x[i] = -200;
					is_carmove[i] = 0;
				}//С����ʧ
				if (zombie_x[z] < 50) {
                    initgraph(Width, High);
					
					mciSendString("close playing.mp3", NULL, 0, NULL);
					mciSendString("close playing.mp3", NULL, 0, NULL);

					putimage(0, 0, &img_lose);//��Ϸ�в��ŵ����ֻ�û�й�,ע��playing
					mciSendString("open lose.mp3", NULL, 0, NULL);
					mciSendString("play lose.mp3", NULL, 0, NULL);
					

					FlushBatchDraw();
					system("pause");
					
				}
			}
		}
	}
	t--;
	if (totalnum == 0) {
		initgraph(Width, High);

		mciSendString("close playing.mp3", NULL, 0, NULL);
		mciSendString("close playing.mp3", NULL, 0, NULL);

		putimage(0, 0, &img_win);//��Ϸ�в��ŵ����ֻ�û�й�,ע��playing
		mciSendString("open win.mp3", NULL, 0, NULL);
		mciSendString("play win.mp3", NULL, 0, NULL);

	    FlushBatchDraw();
		system("pause");
	}

	sun_y += sun_v;//������Ȼ����
	if (sun_y > 700) {//�������δ����ҵ��
		sun_x = rand() % (Width - 100);
		sun_y = -400;
	}
	Sleep(200);

}
void updateWithInput() {//���û������йصĸ���
	MOUSEMSG m;//���������Ϣ
	while (MouseHit()) {//����Ƿ��������Ϣ
		m = GetMouseMsg();
		if (is_peashooter_planted == 0) {//���û����ֲ
			if (m.uMsg == WM_LBUTTONDOWN && score>=100 && m.x >= 95 && m.x < 145 && m.y >= 10 && m.y < 80) {
				is_shooter = 1;
				is_peashooter_moveplant = 1;
				score -= 100;
				mciSendString("close ckmusic", NULL, 0, NULL);
				mciSendString("open clickcard.mp3 alias ckmusic", NULL, 0, NULL);
				mciSendString("play ckmusic", NULL, 0, NULL);
			}
			if (is_peashooter_moveplant == 1) {//ֲ��������ƶ�
				if (m.uMsg == WM_MOUSEMOVE) {
					peashooter_x = m.x - 30;
					peashooter_y = m.y - 30;
				}
			}
			for (i = 0;i < num_width;i++) {
				for (j = 0;j < num_length;j++) {
					if (m.uMsg == WM_LBUTTONDOWN && (m.x > px + sizewidth * j) && (m.x < px + sizewidth * (j + 1)) && (m.y > py + sizehigh * i) && (m.y < py + sizehigh * (i + 1)) && is_peashooter_moveplant == 1) {
						peashooter_x = px + sizewidth * j;
						peashooter_y = py + sizehigh * i;
						is_peashooter_moveplant = 0;
						is_peashooter_planted = 1;//�㶹��������ֲ
						map[i][j] = 1;//��ֲλ��
						mciSendString("close pmusic", NULL, 0, NULL);
						mciSendString("open plant.mp3 alias pmusic", NULL, 0, NULL);
						mciSendString("play pmusic", NULL, 0, NULL);
					}
				}
			}
			if (is_peashooter_planted == 1) {//ʵ�ֶ����ֲ
				is_peashooter_moveplant = 0;
				is_peashooter_planted = 0;
				peashooter_x = 95;
				peashooter_y = 10;
				is_shooter = 0;
			}
		}

		if (is_sunflower_planted == 0) {//���û����ֲ
			if (m.uMsg == WM_LBUTTONDOWN && score >= 50 && m.x >= 155 && m.x < 205 && m.y >= 10 && m.y < 80) {
				is_sunflower = 1;
				is_sunflower_moveplant = 1;
				score -= 50;
				mciSendString("close ckmusic", NULL, 0, NULL);
				mciSendString("open clickcard.mp3 alias ckmusic", NULL, 0, NULL);
				mciSendString("play ckmusic", NULL, 0, NULL);
			}
			if (is_sunflower_moveplant == 1) {//ֲ��������ƶ�
				if (m.uMsg == WM_MOUSEMOVE) {
					sunflower_x = m.x - 30;
					sunflower_y = m.y - 30;
				}
			}
			for (i = 0;i < num_width;i++) {
				for (j = 0;j < num_length;j++) {
					if (m.uMsg == WM_LBUTTONDOWN && (m.x > px + sizewidth * j) && (m.x < px + sizewidth * (j + 1)) && (m.y > py + sizehigh * i) && (m.y < py + sizehigh * (i + 1)) && is_sunflower_moveplant == 1) {
						sunflower_x = px + sizewidth * j;
						sunflower_y = py + sizehigh * i;
						is_sunflower_moveplant = 0;
						is_sunflower_planted = 1;//���տ�����ֲ
						map[i][j] = 2;//��ֲλ��
						mciSendString("close pmusic", NULL, 0, NULL);
						mciSendString("open plant.mp3 alias pmusic", NULL, 0, NULL);
						mciSendString("play pmusic", NULL, 0, NULL);
					}
				}
			}
			if (is_sunflower_planted == 1) {//ʵ�ֶ����ֲ
				is_sunflower_moveplant = 0;
				is_sunflower_planted = 0;
				sunflower_x = 155;
				sunflower_y = 10;
				is_sunflower = 0;
			}
		}


		if (m.uMsg == WM_LBUTTONDOWN && m.x >= sun_x && m.y < sun_x + 100 && m.y >= sun_y && m.y < sun_y + 100) {
			sun_x = rand() % (Width - 100);
			sun_y = -400;
			mciSendString("close sunmusic", NULL, 0, NULL);
			mciSendString("open sun.mp3 alias sunmusic", NULL, 0, NULL);
			mciSendString("play sunmusic", NULL, 0, NULL);
			score = score + 50;//��ҵ������
		}
		
			/*if (m.uMsg == WM_LBUTTONDOWN && m.x >= 50 && m.x < 780 && m.y < 575 && m.y >= 70) {//����ֲ��
				peashooter_x = m.x;
				peashooter_y = m.y;
				is_peashooter_moveplant = 0;
				is_peashooter_planted = 1;

			}*/
	}
}

int main() {
	startup();//���ݳ�ʼ��
	while (1) {
		show();//��ʾ����
		updateWithoutInput();//���û������޹صĸ���
		updateWithInput();//���û������йصĸ���
	}
	return 0;
}